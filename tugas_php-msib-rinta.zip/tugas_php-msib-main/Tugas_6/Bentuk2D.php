<?php 
abstract class Bentuk2D { 
    abstract function luasBidang(); 
    abstract function kelilingBidang(); 
} 
?>
